/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_1242562249;
char *IEEE_P_2592010699;
char *STD_STANDARD;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    ieee_p_1242562249_init();
    work_a_1564865405_3212880686_init();
    work_a_2594314860_3212880686_init();
    work_a_3358698177_3212880686_init();
    work_a_3154045384_3212880686_init();
    work_a_0424650001_3212880686_init();
    work_a_2903997210_3212880686_init();
    work_a_2315667531_3212880686_init();
    work_a_1483647715_3212880686_init();
    work_a_1998556434_3212880686_init();
    work_a_0262810199_3212880686_init();
    work_a_3824059239_3212880686_init();
    work_a_2136731354_3212880686_init();
    work_a_2442724670_3212880686_init();
    work_a_4142268163_3212880686_init();
    work_a_2585400012_2372691052_init();


    xsi_register_tops("work_a_2585400012_2372691052");

    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    STD_STANDARD = xsi_get_engine_memory("std_standard");

    return xsi_run_simulation(argc, argv);

}
